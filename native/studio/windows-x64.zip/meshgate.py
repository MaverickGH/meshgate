"""Native MeshGate validator entry point. See LICENSE."""
import sys as _runtime
if _runtime.implementation.cache_tag != "cpython-311":
    raise RuntimeError("Use the Python 3.11 runtime shipped with MeshGate")
import importlib.util as _util
from pathlib import Path as _Path
_spec = _util.spec_from_file_location('_meshgate_meshgate', _Path(__file__).with_name('_meshgate_meshgate.cp311-win_amd64.pyd'))
_native = _util.module_from_spec(_spec)
_spec.loader.exec_module(_native)
globals().update({k: v for k, v in vars(_native).items() if not k.startswith("__")})
if __name__ == "__main__":
    raise SystemExit(_native.main())
